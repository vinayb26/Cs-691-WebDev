from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

# In-memory storage for user feedback
feedback_list = []

@app.route("/")
def home():
    return render_template("home.html")

@app.route("/feedback", methods=["GET", "POST"])
def feedback():
    if request.method == "POST":
        username = request.form.get("username")
        comments = request.form.get("comments")
        
        # Store feedback in memory
        feedback_list.append({"username": username, "comments": comments})
        
        return render_template("form_result.html", username=username, comments=comments)
    return render_template("feedback.html")

@app.route("/all_feedback")
def all_feedback():
    return render_template("all_feedback.html", feedback_list=feedback_list)

# API endpoint returning JSON data
@app.route("/api/feedback")
def api_feedback():
    return jsonify(feedback_list)

# Custom 404 error page
@app.errorhandler(404)
def page_not_found(e):
    return render_template("404.html"), 404

if __name__ == "__main__":
    app.run(debug=True)
